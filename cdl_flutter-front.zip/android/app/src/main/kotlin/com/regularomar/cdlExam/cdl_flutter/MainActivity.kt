package com.regularomar.cdlExam.cdl_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
